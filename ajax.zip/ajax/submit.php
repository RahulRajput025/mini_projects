<?php
if (isset($_POST['insertData'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $response = array();
    if (empty($username)) {
        $response['error']['username'] = '*Username is required';
    }
    if (empty($password)) {
        $response['error']['password'] = '*Password is required';
    }
    if (empty($response['error'])) {
        $response['data']['username'] = $username;
        $response['data']['password'] = $password;
    }
    echo json_encode($response);
}
?>
